create trigger musteri_temsilci
  after UPDATE
  on fatura
  for each row
  UPDATE musteri_temsilci
       SET Tutar = Tutar + (select Fiyat FROM Fatura_detay where Fatura_detay.F_No = OLD.F_No)
       where M_Id=OLD.M_Id;

